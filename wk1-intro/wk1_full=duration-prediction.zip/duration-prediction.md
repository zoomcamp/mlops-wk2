```python
!python -V
```

    Python 3.12.7



```python
import pandas as pd # working with tabular data
import pickle # for machine learning models
import seaborn as sns # visualization
import matplotlib.pyplot as plt # visualization

from sklearn.feature_extraction import DictVectorizer # Machine Learning
from sklearn.linear_model import LinearRegression # Machine Learning
from sklearn.linear_model import Lasso # Regularization
from sklearn.linear_model import Ridge # Regularization

from sklearn.metrics import mean_squared_error # Loss Function
```


```python
# Download data from NYC: https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page
!mkdir data
# !wget <files>

# !wget https://d37ci6vzurychx.cloudfront.net/trip-data/green_tripdata_2021-01.parquet
# !wget https://d37ci6vzurychx.cloudfront.net/trip-data/green_tripdata_2021-02.parquet
```

    mkdir: cannot create directory ‘data’: File exists



```python
### Load in your parquet files into a pandas dataframe
#df = pd.read_parquet(<path to file>)

df = pd.read_parquet('./data/green_tripdata_2021-01.parquet')
#df = pd.read_parquet('./data/green_tripdata_2021-02.parquet')

# df = pd.read_parquet('./data/fhv_tripdata_2021-01.parquet')
# df = pd.read_parquet('./data/fhv_tripdata_2021-02.parquet')
```


```python
# Calculate your target variable (duration)
# Unlike the csv files the parquet files also stores the data in the datetime format which makes it much easier to operate.
# Pickup and Drop location
# Trip start and end time
# Let’s create a new column duration which calculates the length of each ride :

#df['duration'] = df['lpep_dropoff_datetime'] - df['lpep_pickup_datetime']

# In this case duration is in timedelta format which is not easily trainable. We need to convert this to minutes. 
# This can be done with using the timedelta.total_seconds() function then dividing by 60 to get minutes.

#df['duration_mins'] = df['duration'].apply(lambda td: td.total_seconds() / 60) # we are not doing this for fun, we are doing it to remove 
#outliers as in the link: https://stephen137.github.io/posts/MLOps_Zoomcamp_Week_1/MLOps_Zoomcamp_Week_1.html#:~:text=We%20will%20remove%20these%20outliers%20as%20it%20looks%20as%20if%20they%20are%20due%20to%20measurement%20issues.%20Let%E2%80%99s%20keep%20only%20the%20records%20where%20the%20duration%20was%20between%201%20and%2060%20minutes%20(inclusive).

#df = df[(df.duration >= 1) & (df.duration <= 60)]

```


```python
# Let's look at our updated dataframe :
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 76518 entries, 0 to 76517
    Data columns (total 20 columns):
     #   Column                 Non-Null Count  Dtype         
    ---  ------                 --------------  -----         
     0   VendorID               76518 non-null  int64         
     1   lpep_pickup_datetime   76518 non-null  datetime64[us]
     2   lpep_dropoff_datetime  76518 non-null  datetime64[us]
     3   store_and_fwd_flag     40471 non-null  object        
     4   RatecodeID             40471 non-null  float64       
     5   PULocationID           76518 non-null  int64         
     6   DOLocationID           76518 non-null  int64         
     7   passenger_count        40471 non-null  float64       
     8   trip_distance          76518 non-null  float64       
     9   fare_amount            76518 non-null  float64       
     10  extra                  76518 non-null  float64       
     11  mta_tax                76518 non-null  float64       
     12  tip_amount             76518 non-null  float64       
     13  tolls_amount           76518 non-null  float64       
     14  ehail_fee              0 non-null      object        
     15  improvement_surcharge  76518 non-null  float64       
     16  total_amount           76518 non-null  float64       
     17  payment_type           40471 non-null  float64       
     18  trip_type              40471 non-null  float64       
     19  congestion_surcharge   40471 non-null  float64       
    dtypes: datetime64[us](2), float64(13), int64(3), object(2)
    memory usage: 11.7+ MB



```python
#df.dtypes
# Date time captured a datetime64 and not as Object(String)
```


```python
# Let’s also convert the PULocationID, DOLocationID columns from int64 to strings :

categorical = ['PULocationID', 'DOLocationID']
numerical = ['trip_distance']

### This turns the categorical columns into a list of dictionaries
df[categorical] = df[categorical].astype(str)  ## # Convert to string as it is required in string format for sklearn requirement

train_dicts = df[categorical + numerical].to_dict(orient='records')

dv = DictVectorizer()   # Instantiate a dictionary vectorizer
dv.fit_transform(train_dicts) # # Fit the vectorizer and transform the data into a feature matrix


# You can Convert the feature matrix above into an array
fm_array = fm.toarray() # where fm = dv.fit_transform(train_dicts)

# Print the dimensionality of the feature matrix
dimensionality = fm_array.shape
print("Dimensionality:", dimensionality)


# # And look at our updated dataframe :
# df.info()below

# df.dtypes
```




    <73908x507 sparse matrix of type '<class 'numpy.float64'>'
    	with 221724 stored elements in Compressed Sparse Row format>




```python
# # Transfor str to datetime
# df.lpep_dropoff_datetime = pd.to_datetime(df.lpep_dropoff_datetime) 
# df.lpep_pickup_datetime = pd.to_datetime(df.lpep_pickup_datetime)
```


```python
# And look at our updated dataframe for the 3rd time:
#df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 76518 entries, 0 to 76517
    Data columns (total 20 columns):
     #   Column                 Non-Null Count  Dtype         
    ---  ------                 --------------  -----         
     0   VendorID               76518 non-null  int64         
     1   lpep_pickup_datetime   76518 non-null  datetime64[us]
     2   lpep_dropoff_datetime  76518 non-null  datetime64[us]
     3   store_and_fwd_flag     40471 non-null  object        
     4   RatecodeID             40471 non-null  float64       
     5   PULocationID           76518 non-null  int64         
     6   DOLocationID           76518 non-null  int64         
     7   passenger_count        40471 non-null  float64       
     8   trip_distance          76518 non-null  float64       
     9   fare_amount            76518 non-null  float64       
     10  extra                  76518 non-null  float64       
     11  mta_tax                76518 non-null  float64       
     12  tip_amount             76518 non-null  float64       
     13  tolls_amount           76518 non-null  float64       
     14  ehail_fee              0 non-null      object        
     15  improvement_surcharge  76518 non-null  float64       
     16  total_amount           76518 non-null  float64       
     17  payment_type           40471 non-null  float64       
     18  trip_type              40471 non-null  float64       
     19  congestion_surcharge   40471 non-null  float64       
    dtypes: datetime64[us](2), float64(13), int64(3), object(2)
    memory usage: 11.7+ MB



```python
### Great, we now have a duration column and PULocationID and DOLocationID are now correctly showing as datatype object 
# (categorical data, which includes strings).

```


```python
# Read the data for January. How many records are there?


df.shape
```




    (76518, 22)




```python
# Calculate the duration of each trips in minutes
# df_jan['Duration'] = (df_jan['dropOff_datetime'] - df_jan['pickup_datetime']) / pd.Timedelta(minutes=1)


# df.lpep_dropoff_datetime - df.lpep_pickup_datetime
```




    0       0 days 00:03:56
    1       0 days 00:08:45
    2       0 days 00:05:58
    3       0 days 00:07:05
    4       0 days 00:00:04
                  ...      
    76513   0 days 00:38:00
    76514   0 days 00:38:00
    76515   0 days 00:11:00
    76516   0 days 00:27:00
    76517   0 days 00:10:00
    Length: 76518, dtype: timedelta64[us]




```python
# df['duration'] = df.lpep_dropoff_datetime - df.lpep_pickup_datetime
# df.duration = df.duration.apply(lambda td: td.total_seconds() / 60)
# df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>VendorID</th>
      <th>lpep_pickup_datetime</th>
      <th>lpep_dropoff_datetime</th>
      <th>store_and_fwd_flag</th>
      <th>RatecodeID</th>
      <th>PULocationID</th>
      <th>DOLocationID</th>
      <th>passenger_count</th>
      <th>trip_distance</th>
      <th>fare_amount</th>
      <th>...</th>
      <th>tip_amount</th>
      <th>tolls_amount</th>
      <th>ehail_fee</th>
      <th>improvement_surcharge</th>
      <th>total_amount</th>
      <th>payment_type</th>
      <th>trip_type</th>
      <th>congestion_surcharge</th>
      <th>duration</th>
      <th>duration_mins</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2</td>
      <td>2021-01-01 00:15:56</td>
      <td>2021-01-01 00:19:52</td>
      <td>N</td>
      <td>1.0</td>
      <td>43</td>
      <td>151</td>
      <td>1.0</td>
      <td>1.01</td>
      <td>5.50</td>
      <td>...</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>None</td>
      <td>0.3</td>
      <td>6.80</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>0.00</td>
      <td>3.933333</td>
      <td>3.933333</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>2021-01-01 00:25:59</td>
      <td>2021-01-01 00:34:44</td>
      <td>N</td>
      <td>1.0</td>
      <td>166</td>
      <td>239</td>
      <td>1.0</td>
      <td>2.53</td>
      <td>10.00</td>
      <td>...</td>
      <td>2.81</td>
      <td>0.00</td>
      <td>None</td>
      <td>0.3</td>
      <td>16.86</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2.75</td>
      <td>8.750000</td>
      <td>8.750000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>2021-01-01 00:45:57</td>
      <td>2021-01-01 00:51:55</td>
      <td>N</td>
      <td>1.0</td>
      <td>41</td>
      <td>42</td>
      <td>1.0</td>
      <td>1.12</td>
      <td>6.00</td>
      <td>...</td>
      <td>1.00</td>
      <td>0.00</td>
      <td>None</td>
      <td>0.3</td>
      <td>8.30</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.00</td>
      <td>5.966667</td>
      <td>5.966667</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2</td>
      <td>2020-12-31 23:57:51</td>
      <td>2021-01-01 00:04:56</td>
      <td>N</td>
      <td>1.0</td>
      <td>168</td>
      <td>75</td>
      <td>1.0</td>
      <td>1.99</td>
      <td>8.00</td>
      <td>...</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>None</td>
      <td>0.3</td>
      <td>9.30</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>0.00</td>
      <td>7.083333</td>
      <td>7.083333</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>2021-01-01 00:16:36</td>
      <td>2021-01-01 00:16:40</td>
      <td>N</td>
      <td>2.0</td>
      <td>265</td>
      <td>265</td>
      <td>3.0</td>
      <td>0.00</td>
      <td>-52.00</td>
      <td>...</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>None</td>
      <td>-0.3</td>
      <td>-52.80</td>
      <td>3.0</td>
      <td>1.0</td>
      <td>0.00</td>
      <td>0.066667</td>
      <td>0.066667</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>76513</th>
      <td>2</td>
      <td>2021-01-31 21:38:00</td>
      <td>2021-01-31 22:16:00</td>
      <td>None</td>
      <td>NaN</td>
      <td>81</td>
      <td>90</td>
      <td>NaN</td>
      <td>17.63</td>
      <td>56.23</td>
      <td>...</td>
      <td>0.00</td>
      <td>6.12</td>
      <td>None</td>
      <td>0.3</td>
      <td>65.40</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>38.000000</td>
      <td>38.000000</td>
    </tr>
    <tr>
      <th>76514</th>
      <td>2</td>
      <td>2021-01-31 22:43:00</td>
      <td>2021-01-31 23:21:00</td>
      <td>None</td>
      <td>NaN</td>
      <td>35</td>
      <td>213</td>
      <td>NaN</td>
      <td>18.36</td>
      <td>46.66</td>
      <td>...</td>
      <td>12.20</td>
      <td>6.12</td>
      <td>None</td>
      <td>0.3</td>
      <td>65.28</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>38.000000</td>
      <td>38.000000</td>
    </tr>
    <tr>
      <th>76515</th>
      <td>2</td>
      <td>2021-01-31 22:16:00</td>
      <td>2021-01-31 22:27:00</td>
      <td>None</td>
      <td>NaN</td>
      <td>74</td>
      <td>69</td>
      <td>NaN</td>
      <td>2.50</td>
      <td>18.95</td>
      <td>...</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>None</td>
      <td>0.3</td>
      <td>22.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>11.000000</td>
      <td>11.000000</td>
    </tr>
    <tr>
      <th>76516</th>
      <td>2</td>
      <td>2021-01-31 23:10:00</td>
      <td>2021-01-31 23:37:00</td>
      <td>None</td>
      <td>NaN</td>
      <td>168</td>
      <td>215</td>
      <td>NaN</td>
      <td>14.48</td>
      <td>48.87</td>
      <td>...</td>
      <td>0.00</td>
      <td>6.12</td>
      <td>None</td>
      <td>0.3</td>
      <td>58.04</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>27.000000</td>
      <td>27.000000</td>
    </tr>
    <tr>
      <th>76517</th>
      <td>2</td>
      <td>2021-01-31 23:25:00</td>
      <td>2021-01-31 23:35:00</td>
      <td>None</td>
      <td>NaN</td>
      <td>119</td>
      <td>244</td>
      <td>NaN</td>
      <td>1.81</td>
      <td>15.45</td>
      <td>...</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>None</td>
      <td>0.3</td>
      <td>18.50</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>10.000000</td>
      <td>10.000000</td>
    </tr>
  </tbody>
</table>
<p>76518 rows × 22 columns</p>
</div>




```python
# Filtering


# First look at the distribution of the duration values using seaborn.
sns.distplot(df['duration'])


```

    /tmp/ipykernel_2457/3447682981.py:5: UserWarning: 
    
    `distplot` is a deprecated function and will be removed in seaborn v0.14.0.
    
    Please adapt your code to use either `displot` (a figure-level function with
    similar flexibility) or `histplot` (an axes-level function for histograms).
    
    For a guide to updating your code to use the new functions, please see
    https://gist.github.com/mwaskom/de44147ed2974457ad6372750bbe5751
    
      sns.distplot(df['duration'])





    <Axes: xlabel='duration', ylabel='Density'>




    
![png](output_15_2.png)
    



```python
# Clearly we need some means of filtering the data. One good way is by removing the extreme percentiles at either end. 
# We can determine the percentile cutoffs with the describe function to see where extreme values lie.

df['duration'].describe(percentiles=[0.01, 0.05, 0.95, 0.98, 0.99])

```




    count    73908.000000
    mean        16.852578
    std         11.563163
    min          1.000000
    1%           2.000000
    5%           3.816667
    50%         14.000000
    95%         41.000000
    98%         48.781000
    99%         53.000000
    max         60.000000
    Name: duration, dtype: float64



### Marcu Note; https://github.com/mleiwe/mlops-zoomcamp/blob/Ch1_Marcus/cohorts/2024/01-intro/Ch1_Notes.md



```python
### Data Prep
# SUMMARY we are simply tring to convert all str, categorical, code etc into NUMERICALs

# # One-hot - int to object
# df[categorical] = df[categorical].astype(str)

# Prediction features: Basically what are our X values. In the demo we are using PULocationID and DOLocationID which are the pick up 
# and drop off location IDs respectively. Because these are not really numbers but ID codes, these should be reformatted into str rather 
#than float or int or whichever numerical data type. Additionally these then need to be encoded in some machine readable form.


# One-hot encoding creates new columns for each category and fills them either with a 1 if the category is present or a 0 if it is a different value. 
# The advantage is that it is simple and easy to use. The downside is that you can greatly expand your data size by creating large numbers of columns 
# that are mostly filled with 0s (known as creating data sparsity).

# Method 1: Change the type of your pandas series

##   df_jan_filt[CategoricalColumns] = df_jan_filt[CategoricalColumns].astype(str)

# Method 2: One hot encoding
## There are two ways to do this. You can use the OneHotEnoder by scikit-learn which can work with arrays or you can use the dictionary vectoriser, 
# DictVectorizer.


# OneHotEncoder uses fewer lines of code as you don't need to convert your dataframe into a dictionary. And you can specify which columns you want to 
# encode
# DictVectorizer feels like a lower level code. And it will only one-hot encode columns with string values

### There is not one correct answer for all use cases. Above all remember don't us pd.get_dummies() as if a value is not in your test data but in your 
# train data (or vice versa) then you will induce an error as the inputs won't have the same shape.

### In this example we used the DictVectorizer

  # from sklearn.feature_extraction import DictVectorizer

  # train_dict = df_jan_filt[CategoricalColumns].to_dict(orient='records')
  # dv = DictVectorizer()
  # X_train = dv.fit_transform(train_dict)

### Target feature: This is simply the duration variable so we can just use

# y_train = df_jan_filt['duration']

# NB You can use y_train = df_jan_filt['duration'].values if you need an array instead.

### According to OK Transform from ZooomCamp as in here # https://particle1331.github.io/ok-transformer/nb/mlops/01-intro.html

# To encode categorical features, we use DictVectorizer. This performs one-hot encoding of categorical features while the numerical features are 
# simply passed. Consider a dataset with categorical features f1 with unique values [a, b, c] and f2 with unique values [d, e], and a numerical 
# feature t. The transformed dataset gets features [f1=a, f1=b, f1=c, f2=d, f2=e, t]. For example, {f1: a, f2: e, t: 1.3} is transformed to
# [1, 0, 0, 0, 1, 1.3]. One nice thing about this is that this will not fail with new categories (i.e. these are simply mapped to all zeros).


### According to Steven from ZoomCamp as in here # https://stephen137.github.io/posts/MLOps_Zoomcamp_Week_1/MLOps_Zoomcamp_Week_1.html

# One-hot encoding allows machine learning models to effectively capture categorical information and handle it as numerical input. However, it increases 
# the dimensionality of the data, especially when dealing with variables with many unique categories. This can impact computational efficiency and model 
# performance, especially in cases where the number of categories is large relative to the number of observations.
```


```python
### Training/Model fitting
# From here we can just do simple sk-learn model fitting. NB in this example we will use a different dataset as the test data, there is no need to do 
# any cross-validation. In this case we can run the following code

# from sklearn.linear_model import LinearRegression
# from sklearn.metrics import mean_squared_error

# lin_reg = LinearRegression()

# lin_reg.fit(X_train,y_train)
# y_pred = lin_reg.predict(X_train)

# rmse = mean_squared_error(y_train, y_pred, squared=False)

# print(f"The RMSE is: {rmse}")



# #To produce a simple visualisation you can use seaborn too

# import seaborn as sns

# sns.distplot(y_pred, label='prediction')
# sns.distplot(y_train, label='ground truth')

### `This will not be a really good fit because we are only using categorical values to eastimate a numerical feature`


```


```python
# sns.distplot(df.duration)

# Long Tail with most trips around 10 mins

### How about 
#sns.histplot(df.duration)
```

    /tmp/ipykernel_2457/3056548181.py:1: UserWarning: 
    
    `distplot` is a deprecated function and will be removed in seaborn v0.14.0.
    
    Please adapt your code to use either `displot` (a figure-level function with
    similar flexibility) or `histplot` (an axes-level function for histograms).
    
    For a guide to updating your code to use the new functions, please see
    https://gist.github.com/mwaskom/de44147ed2974457ad6372750bbe5751
    
      sns.distplot(df.duration)





    <Axes: xlabel='duration', ylabel='Density'>




    
![png](output_20_2.png)
    



```python
# Filtering dataset

# Filter trips between 1 and 60 mins

#df.duration.describe()
```


```python
#df['duration'].mean() # it is for fhv data only, not for green data


# df = df[df.trip_type == 2 ]
# df

# df.duration.describe(percentiles = [0.95, 0.98, 0.99]) # Does not apply here

#((df.duration >= 1) & (df.duration <= 60)).mean()
# 0.5169628432956381

# df = df[(df.duration >= 1) & (df.duration <= 60)]

# categorical = ['PULocationID', 'DOLocationID']
# numerical = ['trip_distance']

#td = df.duration.iloc[0]
#td.total_seconds()/60
```

### Training/Model fitting


```python
# Let's start building a model
# Remember: This will not be a really good fit because we are only using categorical values to eastimate a numerical feature but here we are converting
#them into 



df = pd.read_parquet('./data/green_tripdata_2021-01.parquet')

df['duration'] = df.lpep_dropoff_datetime - df.lpep_pickup_datetime
df.duration = df.duration.apply(lambda td: td.total_seconds() / 60)

df = df[(df.duration >= 1) & (df.duration <= 60)]

categorical = ['PULocationID', 'DOLocationID']
numerical = ['trip_distance']

# Convert to string, sklearn requirement
df[categorical] = df[categorical].astype(str) ## For One Hot encoding, values must be passed as string to be converted into numerical 

df                        
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>VendorID</th>
      <th>lpep_pickup_datetime</th>
      <th>lpep_dropoff_datetime</th>
      <th>store_and_fwd_flag</th>
      <th>RatecodeID</th>
      <th>PULocationID</th>
      <th>DOLocationID</th>
      <th>passenger_count</th>
      <th>trip_distance</th>
      <th>fare_amount</th>
      <th>...</th>
      <th>mta_tax</th>
      <th>tip_amount</th>
      <th>tolls_amount</th>
      <th>ehail_fee</th>
      <th>improvement_surcharge</th>
      <th>total_amount</th>
      <th>payment_type</th>
      <th>trip_type</th>
      <th>congestion_surcharge</th>
      <th>duration</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2</td>
      <td>2021-01-01 00:15:56</td>
      <td>2021-01-01 00:19:52</td>
      <td>N</td>
      <td>1.0</td>
      <td>43</td>
      <td>151</td>
      <td>1.0</td>
      <td>1.01</td>
      <td>5.50</td>
      <td>...</td>
      <td>0.5</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>None</td>
      <td>0.3</td>
      <td>6.80</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>0.00</td>
      <td>3.933333</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>2021-01-01 00:25:59</td>
      <td>2021-01-01 00:34:44</td>
      <td>N</td>
      <td>1.0</td>
      <td>166</td>
      <td>239</td>
      <td>1.0</td>
      <td>2.53</td>
      <td>10.00</td>
      <td>...</td>
      <td>0.5</td>
      <td>2.81</td>
      <td>0.00</td>
      <td>None</td>
      <td>0.3</td>
      <td>16.86</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2.75</td>
      <td>8.750000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>2021-01-01 00:45:57</td>
      <td>2021-01-01 00:51:55</td>
      <td>N</td>
      <td>1.0</td>
      <td>41</td>
      <td>42</td>
      <td>1.0</td>
      <td>1.12</td>
      <td>6.00</td>
      <td>...</td>
      <td>0.5</td>
      <td>1.00</td>
      <td>0.00</td>
      <td>None</td>
      <td>0.3</td>
      <td>8.30</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.00</td>
      <td>5.966667</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2</td>
      <td>2020-12-31 23:57:51</td>
      <td>2021-01-01 00:04:56</td>
      <td>N</td>
      <td>1.0</td>
      <td>168</td>
      <td>75</td>
      <td>1.0</td>
      <td>1.99</td>
      <td>8.00</td>
      <td>...</td>
      <td>0.5</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>None</td>
      <td>0.3</td>
      <td>9.30</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>0.00</td>
      <td>7.083333</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2</td>
      <td>2021-01-01 00:26:31</td>
      <td>2021-01-01 00:28:50</td>
      <td>N</td>
      <td>1.0</td>
      <td>75</td>
      <td>75</td>
      <td>6.0</td>
      <td>0.45</td>
      <td>3.50</td>
      <td>...</td>
      <td>0.5</td>
      <td>0.96</td>
      <td>0.00</td>
      <td>None</td>
      <td>0.3</td>
      <td>5.76</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.00</td>
      <td>2.316667</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>76513</th>
      <td>2</td>
      <td>2021-01-31 21:38:00</td>
      <td>2021-01-31 22:16:00</td>
      <td>None</td>
      <td>NaN</td>
      <td>81</td>
      <td>90</td>
      <td>NaN</td>
      <td>17.63</td>
      <td>56.23</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>6.12</td>
      <td>None</td>
      <td>0.3</td>
      <td>65.40</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>38.000000</td>
    </tr>
    <tr>
      <th>76514</th>
      <td>2</td>
      <td>2021-01-31 22:43:00</td>
      <td>2021-01-31 23:21:00</td>
      <td>None</td>
      <td>NaN</td>
      <td>35</td>
      <td>213</td>
      <td>NaN</td>
      <td>18.36</td>
      <td>46.66</td>
      <td>...</td>
      <td>0.0</td>
      <td>12.20</td>
      <td>6.12</td>
      <td>None</td>
      <td>0.3</td>
      <td>65.28</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>38.000000</td>
    </tr>
    <tr>
      <th>76515</th>
      <td>2</td>
      <td>2021-01-31 22:16:00</td>
      <td>2021-01-31 22:27:00</td>
      <td>None</td>
      <td>NaN</td>
      <td>74</td>
      <td>69</td>
      <td>NaN</td>
      <td>2.50</td>
      <td>18.95</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>None</td>
      <td>0.3</td>
      <td>22.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>11.000000</td>
    </tr>
    <tr>
      <th>76516</th>
      <td>2</td>
      <td>2021-01-31 23:10:00</td>
      <td>2021-01-31 23:37:00</td>
      <td>None</td>
      <td>NaN</td>
      <td>168</td>
      <td>215</td>
      <td>NaN</td>
      <td>14.48</td>
      <td>48.87</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>6.12</td>
      <td>None</td>
      <td>0.3</td>
      <td>58.04</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>27.000000</td>
    </tr>
    <tr>
      <th>76517</th>
      <td>2</td>
      <td>2021-01-31 23:25:00</td>
      <td>2021-01-31 23:35:00</td>
      <td>None</td>
      <td>NaN</td>
      <td>119</td>
      <td>244</td>
      <td>NaN</td>
      <td>1.81</td>
      <td>15.45</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>None</td>
      <td>0.3</td>
      <td>18.50</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>10.000000</td>
    </tr>
  </tbody>
</table>
<p>73908 rows × 21 columns</p>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Index: 73908 entries, 0 to 76517
    Data columns (total 21 columns):
     #   Column                 Non-Null Count  Dtype         
    ---  ------                 --------------  -----         
     0   VendorID               73908 non-null  int64         
     1   lpep_pickup_datetime   73908 non-null  datetime64[us]
     2   lpep_dropoff_datetime  73908 non-null  datetime64[us]
     3   store_and_fwd_flag     38175 non-null  object        
     4   RatecodeID             38175 non-null  float64       
     5   PULocationID           73908 non-null  object        
     6   DOLocationID           73908 non-null  object        
     7   passenger_count        38175 non-null  float64       
     8   trip_distance          73908 non-null  float64       
     9   fare_amount            73908 non-null  float64       
     10  extra                  73908 non-null  float64       
     11  mta_tax                73908 non-null  float64       
     12  tip_amount             73908 non-null  float64       
     13  tolls_amount           73908 non-null  float64       
     14  ehail_fee              0 non-null      object        
     15  improvement_surcharge  73908 non-null  float64       
     16  total_amount           73908 non-null  float64       
     17  payment_type           38175 non-null  float64       
     18  trip_type              38175 non-null  float64       
     19  congestion_surcharge   38175 non-null  float64       
     20  duration               73908 non-null  float64       
    dtypes: datetime64[us](2), float64(14), int64(1), object(4)
    memory usage: 12.4+ MB



```python
# # Apply DictVectorizer ==> Assign dependent variables, Location pair and distance

# ### First, Concatenate the pickup and dropoff location as categorial value
#         # Concatenate the pickup and dropoff location as categorial value
#         # Better prediction than Individual categorial values 

# # df_train['PU_DO'] = df_train['PULocationID'] + '_' + df_train['DOLocationID']
# # df_val['PU_DO'] = df_val['PULocationID'] + '_' + df_val['DOLocationID']


# # categorical = ['PU_DO']
# # # categotical = ['PULocationID', 'DOLocationID']
# # # mean_squared_error ~ 10
# # numerical = ['trip_distance']



# dv = DictVectorizer()

# train_dicts = df[categorical + numerical].to_dict(orient='records') ##One hot encoding
# X_train = dv.fit_transform(train_dicts)  ### codes for pickup and dropoff are converted to numerical or sparse matrix

# val_dicts = df_val[categotical + numerical].to_dict(orient='records')   ##One hot encoding
# X_val = dv.transform(val_dicts)   ### codes for pickup and dropoff are converted to numerical or sparse matrix

# ### Assign target variable, Duration
# #Extract target variable ==>y_train = df[TargetColumn].values
# target = 'duration'
# y_train = df_train[target].values
# y_val = df_val[target].values


# ### Use LinearRegression to fit Model as in 
# # FIT model: ==> model.fit(X_train, y_train)
# lr = LinearRegression()
# lr.fit(X_train, y_train)


# # PREDICT Model:  y_pred = model.predict(X_train)
# y_pred = lr.predict(X_val)

# #Measure goodness of fit ==> rmse = mean_squared_error(y_train, y_pred, squared=False)
# mean_squared_error(y_val, y_pred)  #, squared=False)
```


```python
# ### First, Concatenate the pickup and dropoff location as categorial value
#     # Concatenate the pickup and dropoff location as categorial value because it is a Better prediction than Individual categorial values 

# ###  WHY???  Remember: This will not be a really good fit because we are only using categorical values to eastimate a numerical feature but 
# #here we are converting them into 

# df_train['PU_DO'] = df_train['PULocationID'] + '_' + df_train['DOLocationID']
# df_val['PU_DO'] = df_val['PULocationID'] + '_' + df_val['DOLocationID']



# categorical = ['PU_DO']   # categotical = ['PULocationID', 'DOLocationID']
# # mean_squared_error ~ 10
# numerical = ['trip_distance']
```


```python
### Use LinearRegression

target = 'duration'
y_train = df[target].values

lr = LinearRegression()
lr.fit(X_train, y_train)

y_pred = lr.predict(X_train)

mean_squared_error(y_train, y_pred)
```


```python

```


```python
train_dicts = df[categorical + numerical].to_dict(orient='records')

dv = DictVectorizer()
dv.fit_transform(train_dicts)


### Check if True or False
dv.fit_transform(train_dicts).todense().shape[1] == df.PULocationID.nunique() + df.DOLocationID.nunique() + 1

### Each trip is represented by a dictionary containing three features:
train_dicts[:3]

### The location IDs are one-hot encoded and the dataset is converted to a sparse matrix:

dv.transform(train_dicts[:3]).todense()
```


    ---------------------------------------------------------------------------

    KeyError                                  Traceback (most recent call last)

    Cell In[81], line 1
    ----> 1 train_dicts = df[categorical + numerical].to_dict(orient='records')
          3 dv = DictVectorizer()
          4 dv.fit_transform(train_dicts)


    File ~/anaconda3/lib/python3.12/site-packages/pandas/core/frame.py:4108, in DataFrame.__getitem__(self, key)
       4106     if is_iterator(key):
       4107         key = list(key)
    -> 4108     indexer = self.columns._get_indexer_strict(key, "columns")[1]
       4110 # take() does not accept boolean indexers
       4111 if getattr(indexer, "dtype", None) == bool:


    File ~/anaconda3/lib/python3.12/site-packages/pandas/core/indexes/base.py:6200, in Index._get_indexer_strict(self, key, axis_name)
       6197 else:
       6198     keyarr, indexer, new_indexer = self._reindex_non_unique(keyarr)
    -> 6200 self._raise_if_missing(keyarr, indexer, axis_name)
       6202 keyarr = self.take(indexer)
       6203 if isinstance(key, Index):
       6204     # GH 42790 - Preserve name from an Index


    File ~/anaconda3/lib/python3.12/site-packages/pandas/core/indexes/base.py:6252, in Index._raise_if_missing(self, key, indexer, axis_name)
       6249     raise KeyError(f"None of [{key}] are in the [{axis_name}]")
       6251 not_found = list(ensure_index(key)[missing_mask.nonzero()[0]].unique())
    -> 6252 raise KeyError(f"{not_found} not in index")


    KeyError: "['PU_DO'] not in index"



```python
# ## Read Jan & Feb dataset

# # Training dataset   - JAN
# df_train = pd.read_parquet('./data/green_tripdata_2021-01.parquet')
# # Validation dataset - FEB
# df_val = pd.read_parquet('./data/green_tripdata_2021-02.parquet')
```
Compare Jan & Feb dataset

```python
# Compare length of both dataset
len(df_train), len(df_val)
```


```python

```


```python

```

### OK TRANSFORMER https://particle1331.github.io/ok-transformer/nb/mlops/01-intro.html



```python
### OK TRANSFORMER https://particle1331.github.io/ok-transformer/nb/mlops/01-intro.html

df['duration (min)'] = (df.lpep_dropoff_datetime - df.lpep_pickup_datetime).dt.total_seconds() / 60
sns.histplot(df['duration (min)'].values);

# sns.distplot(y_pred, label='prediction')
# sns.distplot(y_train, label='actual')

# plt.legend()
```


    
![png](output_37_0.png)
    



```python
df['duration (min)'].describe(percentiles=[0.95, 0.98, 0.99])
```




    count    1238.000000
    mean       18.305493
    std       108.364382
    min         0.000000
    50%         1.666667
    95%        35.604167
    98%        59.339333
    99%       149.837833
    max      1416.100000
    Name: duration (min), dtype: float64




```python
# Notice the longest trip took ~1400 minutes and there are trips which took <1 minute. We also see that 98% of all rides are within 1 hour. 
# From a business perspective, it makes sense to predict durations that are at least one minute, and at most an hour. 
# Checking the fraction of the dataset with duration that fall in this range:
```


```python
((df['duration (min)'] >= 1) & (df['duration (min)'] <= 60)).mean()
```




    0.5169628432956381




```python
df = df[(df['duration (min)'] >= 1) & (df['duration (min)'] <= 60)]
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>VendorID</th>
      <th>lpep_pickup_datetime</th>
      <th>lpep_dropoff_datetime</th>
      <th>store_and_fwd_flag</th>
      <th>RatecodeID</th>
      <th>PULocationID</th>
      <th>DOLocationID</th>
      <th>passenger_count</th>
      <th>trip_distance</th>
      <th>fare_amount</th>
      <th>...</th>
      <th>tolls_amount</th>
      <th>ehail_fee</th>
      <th>improvement_surcharge</th>
      <th>total_amount</th>
      <th>payment_type</th>
      <th>trip_type</th>
      <th>congestion_surcharge</th>
      <th>duration</th>
      <th>duration_mins</th>
      <th>duration (min)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>30</th>
      <td>2</td>
      <td>2021-01-01 00:35:29</td>
      <td>2021-01-01 00:55:15</td>
      <td>N</td>
      <td>5.0</td>
      <td>74</td>
      <td>247</td>
      <td>1.0</td>
      <td>3.64</td>
      <td>13.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>None</td>
      <td>0.3</td>
      <td>13.3</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0 days 00:19:46</td>
      <td>19.766667</td>
      <td>19.766667</td>
    </tr>
    <tr>
      <th>53</th>
      <td>2</td>
      <td>2021-01-01 01:54:51</td>
      <td>2021-01-01 02:15:35</td>
      <td>N</td>
      <td>5.0</td>
      <td>74</td>
      <td>94</td>
      <td>1.0</td>
      <td>5.82</td>
      <td>18.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>None</td>
      <td>0.3</td>
      <td>18.3</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0 days 00:20:44</td>
      <td>20.733333</td>
      <td>20.733333</td>
    </tr>
    <tr>
      <th>69</th>
      <td>2</td>
      <td>2021-01-01 02:42:49</td>
      <td>2021-01-01 02:50:59</td>
      <td>N</td>
      <td>5.0</td>
      <td>136</td>
      <td>241</td>
      <td>1.0</td>
      <td>0.57</td>
      <td>9.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>None</td>
      <td>0.3</td>
      <td>9.3</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0 days 00:08:10</td>
      <td>8.166667</td>
      <td>8.166667</td>
    </tr>
    <tr>
      <th>88</th>
      <td>2</td>
      <td>2021-01-01 04:52:02</td>
      <td>2021-01-01 05:05:01</td>
      <td>N</td>
      <td>5.0</td>
      <td>247</td>
      <td>75</td>
      <td>1.0</td>
      <td>3.43</td>
      <td>15.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>None</td>
      <td>0.3</td>
      <td>15.3</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0 days 00:12:59</td>
      <td>12.983333</td>
      <td>12.983333</td>
    </tr>
    <tr>
      <th>96</th>
      <td>2</td>
      <td>2021-01-01 05:52:43</td>
      <td>2021-01-01 05:58:02</td>
      <td>N</td>
      <td>5.0</td>
      <td>7</td>
      <td>7</td>
      <td>1.0</td>
      <td>0.65</td>
      <td>50.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>None</td>
      <td>0.3</td>
      <td>57.3</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0 days 00:05:19</td>
      <td>5.316667</td>
      <td>5.316667</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 23 columns</p>
</div>




```python
sns.histplot(df['duration (min)'].values)
plt.xlabel("duration (min)");
```


    
![png](output_42_0.png)
    



```python
### Feature encoding
For the first iteration of the model, we choose only a few variables. In particular, we exclude datetime features which can be relevant. Is it a weekend,
### or a holiday? From experience, we know that these factors can have a large effect on ride duration. But for a first iteration, we only choose the 
### following three features:

# categorical = ['PULocationID', 'DOLocationID']
# numerical = ['trip_distance']

# # Convert to string, sklearn requirement
# df[categorical] = df[categorical].astype(str)

### According to OK Transform as in here # https://particle1331.github.io/ok-transformer/nb/mlops/01-intro.html

# To encode categorical features, we use DictVectorizer. This performs one-hot encoding of categorical features while the numerical features are 
# simply passed. Consider a dataset with categorical features f1 with unique values [a, b, c] and f2 with unique values [d, e], and a numerical 
# feature t. The transformed dataset gets features [f1=a, f1=b, f1=c, f2=d, f2=e, t]. For example, {f1: a, f2: e, t: 1.3} is transformed to
# [1, 0, 0, 0, 1, 1.3]. One nice thing about this is that this will not fail with new categories (i.e. these are simply mapped to all zeros).
```


```python

```


```python
# Let’s also convert the PULocationID, DOLocationID columns from int64 to strings :

categorical = ['PULocationID', 'DOLocationID']
numerical = ['trip_distance']

df[categorical] = df[categorical].astype(str)  ## # Convert to string as it is required in string format for sklearn requirement

train_dicts = df[categorical + numerical].to_dict(orient='records')

dv = DictVectorizer()
dv.fit_transform(train_dicts)
```




    <73908x507 sparse matrix of type '<class 'numpy.float64'>'
    	with 221724 stored elements in Compressed Sparse Row format>




```python
dv.fit_transform(train_dicts).todense().shape[1] == df.PULocationID.nunique() + df.DOLocationID.nunique() + 1
```




    True




```python
train_dicts[:3]
```




    [{'PULocationID': '43', 'DOLocationID': '151', 'trip_distance': 1.01},
     {'PULocationID': '166', 'DOLocationID': '239', 'trip_distance': 2.53},
     {'PULocationID': '41', 'DOLocationID': '42', 'trip_distance': 1.12}]




```python
dv.transform(train_dicts[:3]).todense()
```




    matrix([[0.  , 0.  , 0.  , ..., 0.  , 0.  , 1.01],
            [0.  , 0.  , 0.  , ..., 0.  , 0.  , 2.53],
            [0.  , 0.  , 0.  , ..., 0.  , 0.  , 1.12]])




```python
### Baseline model

# In this section, we will train a linear regression model. Note that the validation set consists of data one month after the training set. 
# We will define a sequence of transformations that will be applied to the dataset to get the model features. Note that the model is trained and 
# evaluated only on rides that fall between 1 to 60 minutes.

def filter_ride_duration(df):
    # Create target column and filter outliers
    df['duration (min)'] = df.lpep_dropoff_datetime - df.lpep_pickup_datetime   # seconds
    df['duration (min)'] = df['duration (min)'].dt.total_seconds() / 60
    return df[(df['duration (min)'] >= 1) & (df['duration (min)'] <= 60)]

def convert_to_dict(df, features):
    # Convert dataframe to feature dicts
    return df[features].to_dict(orient='records')

def preprocess(df, cat, num):
    df = filter_ride_duration(df)
    df[cat] = df[cat].astype(str)
    df[num] = df[num].astype(float)
    return df

### Note that the above preprocessing steps apply to all datasets (i.e. no concern of data leak). In the following, observe that the vectorizer only sees 
# the training data:
```


```python
df.shape
```




    (73908, 21)




```python
### In the following, observe that the vectorizer only sees the training data:


# Load data
df_train = pd.read_parquet('./data/green_tripdata_2021-01.parquet')
df_valid = pd.read_parquet('./data/green_tripdata_2021-02.parquet')

# Preprocessing
cat = ['PULocationID', 'DOLocationID']
num = ['trip_distance']

df_train = preprocess(df_train, cat=cat, num=num)
df_valid = preprocess(df_valid, cat=cat, num=num)

# Preparing features
features = ['PULocationID', 'DOLocationID', 'trip_distance']
D_train = convert_to_dict(df_train, features=features)
D_valid = convert_to_dict(df_valid, features=features)
y_train = df_train['duration (min)']
y_valid = df_valid['duration (min)']

# Fit all known categories
dv = DictVectorizer()
dv.fit(D_train)
X_train = dv.transform(D_train)
X_valid = dv.transform(D_valid)


```

    /tmp/ipykernel_2457/961437744.py:19: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df[cat] = df[cat].astype(str)
    /tmp/ipykernel_2457/961437744.py:20: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df[num] = df[num].astype(float)
    /tmp/ipykernel_2457/961437744.py:19: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df[cat] = df[cat].astype(str)
    /tmp/ipykernel_2457/961437744.py:20: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df[num] = df[num].astype(float)



```python
### Training a linear model:

def plot_duration_histograms(y_train, p_train, y_valid, p_valid):
    """Plot true and prediction distributions of ride duration."""
    
    fig, ax = plt.subplots(1, 2, figsize=(8, 4))

    sns.histplot(p_train, ax=ax[0], label='pred', color='C0', stat='density', kde=True)
    sns.histplot(y_train, ax=ax[0], label='true', color='C1', stat='density', kde=True)
    ax[0].set_title("Train")
    ax[0].legend()

    sns.histplot(p_valid, ax=ax[1], label='pred', color='C0', stat='density', kde=True)
    sns.histplot(y_valid, ax=ax[1], label='true', color='C1', stat='density', kde=True)
    ax[1].set_title("Valid")
    ax[1].legend()

    fig.tight_layout();


lr = LinearRegression()
lr.fit(X_train, y_train)

p_train = lr.predict(X_train)
p_valid = lr.predict(X_valid)
plot_duration_histograms(y_train, p_train, y_valid, p_valid)
```


    
![png](output_52_0.png)
    



```python
print("RMSE (train):", mean_squared_error(y_train, lr.predict(X_train)))
print("RMSE (valid):", mean_squared_error(y_valid, lr.predict(X_valid)))
```

    RMSE (train): 96.80198150225021
    RMSE (valid): 110.23132573784106



```python
### Using interaction features
# Instead of learning separate weights for the pickup and drop off locations, we consider learning weights for combinations of pickup and drop off 
# locations. Note we can also add pick up point as additional feature since we know from experience that directionality can be important.


def add_location_interaction(df):
    df['PU_DO'] = df['PULocationID'] + '_' + df['DOLocationID']
    return df

# Load data
df_train = pd.read_parquet('./data/green_tripdata_2021-01.parquet')
df_valid = pd.read_parquet('./data/green_tripdata_2021-02.parquet')

# Preprocessing
cat = ['PULocationID', 'DOLocationID']
num = ['trip_distance']
df_train = preprocess(df_train, cat=cat, num=num)
df_valid = preprocess(df_valid, cat=cat, num=num)

# Preparing features
df_train = add_location_interaction(df_train)
df_valid = add_location_interaction(df_valid)

features = ['PU_DO', 'trip_distance']
D_train = convert_to_dict(df_train, features=features)
D_valid = convert_to_dict(df_valid, features=features)
y_train = df_train['duration (min)']
y_valid = df_valid['duration (min)']

# Fit all known categories
dv = DictVectorizer()
dv.fit(D_train)
X_train = dv.transform(D_train)
X_valid = dv.transform(D_valid)
```

    /tmp/ipykernel_2457/961437744.py:19: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df[cat] = df[cat].astype(str)
    /tmp/ipykernel_2457/961437744.py:20: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df[num] = df[num].astype(float)
    /tmp/ipykernel_2457/961437744.py:19: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df[cat] = df[cat].astype(str)
    /tmp/ipykernel_2457/961437744.py:20: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df[num] = df[num].astype(float)



```python
### Using the same model:

lr = LinearRegression()
lr.fit(X_train, y_train)

p_train = lr.predict(X_train)
p_valid = lr.predict(X_valid)
plot_duration_histograms(y_train, p_train, y_valid, p_valid)
```


    
![png](output_55_0.png)
    



```python
print("RMSE (train):", mean_squared_error(y_train, lr.predict(X_train)))
print("RMSE (valid):", mean_squared_error(y_valid, lr.predict(X_valid)))
```

    RMSE (train): 32.4850311374611
    RMSE (valid): 60.19766164981667



```python
### Persisting the model

with open('models/lin_reg.bin', 'wb') as fout:
    pickle.dump((dv, lr), fout)
```


```python
# Print the dimensionality of the feature matrix
dimensionality = X_train.shape
print("Dimensionality:", dimensionality)
```

    Dimensionality: (73908, 13221)



```python
### So our feature matrix has 73908 rows and 13221 columns (originally (76518, 22) prior to one hot encoding and 
# before removing outlier above 1 & 60min (73908, 21)).

# Note: rows remianed the same for all?? Is this true??
```


```python

```

### Stephen from ZoomCamp : https://stephen137.github.io/posts/MLOps_Zoomcamp_Week_1/MLOps_Zoomcamp_Week_1.html


```python
# Customized pre-processing function
# We have carried out a lot of steps to get our data fit for training. We could automate this by creating a customized function :


def read_dataframe(filename):
    if filename.endswith('.csv'):
        df = pd.read_csv(filename)

        df.tpep_dropoff_datetime = pd.to_datetime(df.tpep_dropoff_datetime)
        df.tpep_pickup_datetime = pd.to_datetime(df.tpep_pickup_datetime)
    elif filename.endswith('.parquet'):
        df = pd.read_parquet(filename)

    df['duration'] = df.tpep_dropoff_datetime - df.tpep_pickup_datetime
    df.duration = df.duration.apply(lambda td: td.total_seconds() / 60)

    df = df[(df.duration >= 1) & (df.duration <= 60)]

    categorical = ['PULocationID', 'DOLocationID']
    df[categorical] = df[categorical].astype(str)
    
    return df
    
```


```python

```


```python
# Training a model
# Let’s now let’s use the feature matrix from the previous step to train a Linear Regression model :

------------------------------------------------------------------------------
# turn the categorical columns into a list of dictionaries e.g.
# list_of_dicts = yellow_jan_22[categorical].to_dict(orient='records')

# Convert categorical columns to a dictionary
train_dicts = yellow_jan_22[categorical].to_dict(orient='records')

# Instantiate a dictionary vectorizer
dv = DictVectorizer()

-----------------------------------------------------------------------------
# Fit the vectorizer and transform the data into a feature matrix e.g.
# fm = dv.fit_transform(list_of_dicts)

# Convert the feature matrix to an array
fm_array = fm.toarray()
-----------------------------------------------------------------------------
# Print the dimensionality of the feature matrix
dimensionality = fm_array.shape
print("Dimensionality:", dimensionality)


# Set up trainign set
X_train = dv.fit_transform(train_dicts)


# define target variable and assign to y_train
target = 'duration'
y_train = yellow_jan_22[target].values


# instantiate linear regression model with default parameters
lr = LinearRegression()

# fit model to training data
lr.fit(X_train, y_train)


### Get predictions
# Once the model is trained, it can be used to make predictions by plugging in new values for the independent variables. The model assumes that the 
# relationship between the variables remains linear and that the underlying assumptions, such as linearity, independence, and homoscedasticity, hold true.

# get predictions
y_pred = lr.predict(X_train)


### Loss function - RMSE
# The process of building a linear regression model involves estimating the coefficients that minimize a chosen error metric, such as the mean squared 
# error (MSE). This is typically done using a technique called ordinary least squares (OLS), which finds the coefficients that minimize the sum of squared
# differences between the predicted and actual values.

#The RMSE is the square root of the mean squared error (MSE).
# calculate RMSE
mean_squared_error(y_train, y_pred, squared=False) # squared = False so this is root MSE (RMSE)
```

Linear Regression
A linear regression model is a statistical approach used to model the relationship between a dependent variable and one or more independent variables. It assumes a linear relationship between the variables and aims to find the best-fitting line that minimizes the differences between the predicted and actual values.

The model assumes that the dependent variable can be expressed as a linear combination of the independent variables, where each independent variable is multiplied by a coefficient and summed together with an intercept term. The coefficients represent the effect of each independent variable on the dependent variable, and the intercept term represents the expected value of the dependent variable when all independent variables are zero.

Linear regression models are widely used for various purposes, such as predicting sales based on advertising expenditure, analyzing the impact of independent variables on a dependent variable, and making forecasts.

In our case we are going to used linear regression to predict the duration of taxi rides.


```python
### Evaluating our model - validation set

# Let’s evaluate our model on the unseen Yellow Taxi February 2022 dataset that we downloaded earlier :

# read in the validation set
yellow_feb_22 = pd.read_parquet('yellow_tripdata_2022-02.parquet')

# create a new column 'duration' in minutes
yellow_feb_22['duration'] = yellow_feb_22.tpep_dropoff_datetime - yellow_feb_22.tpep_pickup_datetime
# convert duration to seconds
yellow_feb_22.duration = yellow_feb_22.duration.apply(lambda td: td.total_seconds()/60)

# define categorical and numerical columns
categorical = ['PULocationID', 'DOLocationID']
numerical = ['trip_distance']

# convert categorical columns to strings
yellow_feb_22[categorical] = yellow_feb_22[categorical].astype(str)

# remove outliers by clipping duration between 1 and 60 mins
yellow_feb_22 = yellow_feb_22[(yellow_feb_22.duration >= 1) & (yellow_feb_22.duration <= 60)]

# Instantiate a dictionary vectorizer
dv = DictVectorizer()

# reinstate our training set
train_dicts = yellow_jan_22[categorical].to_dict(orient='records')
X_train = dv.fit_transform(train_dicts)

# turn the categorical columns into a list of dictionaries
val_dicts = yellow_feb_22[categorical].to_dict(orient='records')
X_val = dv.transform(val_dicts)

# define target variable and assign to y_val
target = 'duration'
y_train = yellow_jan_22[target].values
y_val = yellow_feb_22[target].values

# instantiate & fit our model to the TRAINING set
lr = LinearRegression()
lr.fit(X_train,y_train)

# Get predictions for the VALIDATION set
y_pred = lr.predict(X_val)

# calculate RMSE
mean_squared_error(y_val, y_pred, squared=False) # squared = False so this is root MSE (RMSE

# Visualization
# We can visualize our predictions versus actuals using the Seaborn library :

sns.distplot(y_pred, label='prediction')
sns.distplot(y_train, label='actual')

plt.legend()
```

# Other models
# Least Absolute Shrinkage and Selection Operator(Lasso)

Lasso regularization adds the absolute value of the coefficients multiplied by a constant, called the regularization parameter or alpha, to the loss function. The main characteristic of Lasso is that it can shrink coefficients all the way to zero, effectively performing feature selection by eliminating irrelevant or less important features. This property makes Lasso useful when dealing with high-dimensional datasets or when trying to identify the most significant predictors.

Lasso tends to perform well when there are many irrelevant features or a need for feature selection. However, it can struggle with highly correlated features or situations where there are more predictors than observations.


```python
lr = Las
so() # default parameters
lr.fit(X_train, y_train)

y_pred - lr.predict(X_val)

mean_squared_error(y_val, y_pred, squared=False)


lr = Lasso(alpha=0.01) # try using different values for alpha - this controls the speed of gradient descent
lr.fit(X_train, y_train)

y_pred - lr.predict(X_val)

mean_squared_error(y_val, y_pred, squared=False)

```

### Ridge (Tikhonov regularization or L2 regularization)

Ridge regularization adds the squared value of the coefficients multiplied by the regularization parameter to the loss function. Unlike Lasso, Ridge does not eliminate coefficients entirely but shrinks them towards zero without reaching zero. This leads to a reduction in the magnitude of the coefficients, effectively reducing model complexity. Ridge regularization is particularly useful when dealing with multicollinearity, a situation where predictor variables are highly correlated.

The choice between Lasso and Ridge regularization depends on the specific characteristics of the dataset and the goals of the analysis. In practice, it’s common to try both techniques and select the one that yields the best results or combine them in a hybrid approach called Elastic Net regularization.


```python
lr = Ridge(alpha=0.01) # try using different values for alpha - this controls the speed of gradient descent
lr.fit(X_train, y_train)

y_pred - lr.predict(X_val)

mean_squared_error(y_val, y_pred, squared=False)
```

Both the Lasso and Ridge models produce the same results as our standard Linear Regresssion model. This is hardly surprising as our model is only looking at two features, PULocationID and DOLocationID. Let’s include more features.

### Feature engineering
Feature engineering is the process of transforming raw data into meaningful and informative features that can be used by machine learning algorithms. It involves selecting, extracting, and manipulating data attributes to enhance the performance of a model. The goal is to create features that capture relevant patterns, relationships, and insights from the data, leading to better predictive power.

Feature engineering techniques include handling missing values, scaling or normalizing numerical features, encoding categorical variables, creating new features through mathematical operations or domain knowledge, and reducing dimensionality through techniques like principal component analysis (PCA).

Effective feature engineering can significantly impact the performance of machine learning models by improving their accuracy, robustness, and interpretability.

Let’s try Linear Regression again with our categorical columns updated for this new feature:


```python
df_train = read_dataframe('yellow_tripdata_2022-01.parquet')
df_val = read_dataframe('yellow_tripdata_2022-02.parquet')

df_train['PU_DO'] = df_train['PULocationID'] + '_' + df_train['DOLocationID']
df_val['PU_DO'] = df_val['PULocationID'] + '_' + df_val['DOLocationID']

categorical = ['PU_DO'] #'PULocationID', 'DOLocationID']
numerical = ['trip_distance']

dv = DictVectorizer()

train_dicts = df_train[categorical].to_dict(orient='records')
X_train = dv.fit_transform(train_dicts)

val_dicts = df_val[categorical].to_dict(orient='records')
X_val = dv.transform(val_dicts)

target = 'duration'
y_train = df_train[target].values
y_val = df_val[target].values

lr = LinearRegression()
lr.fit(X_train, y_train)

y_pred = lr.predict(X_val)

mean_squared_error(y_val, y_pred, squared=False)
```

***That is a significant improvement. The average prediction error is now down to 5.42 minutes, from 7.79.***

### Saving our model
Pickling is a process in Python that allows you to serialize (convert into a byte stream) and store objects, such as machine learning models, in a file. This serialized object can be saved to disk and later loaded back into memory, allowing you to preserve the model’s state for future use.

The pickle module in Python provides functions for pickling and unpickling objects. When you pickle a model, it saves the model’s parameters, internal state, and other necessary information required for its operation. This allows you to save trained models and use them later without needing to retrain them every time.

Pickling a model is useful for various purposes, such as:

Saving trained models: You can pickle your trained model and store it as a file. Later, you can load the model from the file and use it for making predictions without the need to retrain the model.

Sharing models: Pickling enables you to share models with others, allowing them to use your trained model without requiring access to the original training data or retraining the model.

Deploying models in production: You can pickle a trained model and load it into a production environment for making real-time predictions.

# First, let’s create a new directory to store our model :
!mkdir models





```python
# And save our model :

with open('./models/lin_reg.bin', 'wb') as f_out: # wb means write binary mlops-zoomcamp/week_1/models
    try:
        # Pickle both the dictionary vectorizer and the linear regression model
        pickle.dump((dv, lr), f_out)
        print("Model successfully pickled.")
    except Exception as e:
        print("Error occurred while pickling the model:", str(e))

Model successfully pickled.
```
